import numpy as np

def gap_metrics(df, protected_col:str, target_col:str, pred_col:str, thres:float) -> dict:
    '''
    Calculates the parity gap, specificity gap, and recall gap for a protected variable with two groups.
    Inputs:
       df: pandas dataframe
       protected_col: name of column in df corresponding to protected variable
       target_col: name of column in df corresponding to binary classification target, in {0, 1}
       pred_col: name of column in df corresponding to classifier prediction, in [0, 1]
       thres: decision threshold to round pred_col
    Output:
       Dictionary of three elements with structure {gap_name:{group_name:gap}}. Positive values
         should indicate better performance in that group.
         Ex: {
             'parity': {'M': 0.15, 'F':-0.15},
             'specificity': {'M': -0.2, 'F':0.2},
             'recall': {'M': 0.31, 'F':-0.31}
         }
    '''

    pass

def recall_gap_multigroup(df, protected_col:str, target_col:str, pred_col:str, thres:float) -> dict:
    '''
    Calculates the recall gaps for a protected_col with potentially more than two unique values.
    Inputs:
       df: pandas dataframe
       protected_col: name of column in df corresponding to protected variable
       target_col: name of column in df corresponding to binary classification target, in {0, 1}
       pred_col: name of column in df corresponding to classifier prediction, in [0, 1]
       thres: decision threshold to round pred_col
    Output:
       Dictionary mapping str:float, with each entry representing the gap in favor for a group.
         Ex: {
            'Medicare': 0.4,
            'Medicaid': -0.2,
            ...
         }
    '''
    
    pass